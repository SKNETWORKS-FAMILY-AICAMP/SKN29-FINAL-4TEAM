"""Operations integration tests."""
