"""Consultation unit tests."""
