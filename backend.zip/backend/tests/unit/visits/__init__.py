"""Field-visit unit tests."""
